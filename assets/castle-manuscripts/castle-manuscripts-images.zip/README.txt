Castle Manuscripts image assets
1. castle-manuscripts-icon.jpg — antique castle icon artwork
2. castle-manuscript-chinese.jpg — Chinese manuscript artwork
3. castle-manuscript-greek.jpg — Greek manuscript artwork

Upload these three files to the GitHub repository, for example under:
assets/castle-manuscripts/
Keep the filenames unchanged so the website can reference them.
